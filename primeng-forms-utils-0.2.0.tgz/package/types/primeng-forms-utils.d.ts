import * as i0 from '@angular/core';
import { OnDestroy, ChangeDetectorRef, SimpleChanges, OnChanges, OnInit } from '@angular/core';
import { ValidatorFn, AbstractControlOptions, ValidationErrors, FormGroup } from '@angular/forms';

type DynamicFieldType = "text" | "number" | "money" | "percent" | "textarea" | "select" | "enum" | "image" | "date" | "radio" | "checkbox";
type DynamicOptionLayout = "vertical" | "horizontal";
type DynamicValidatorType = "required" | "email" | "min" | "max" | "minLength" | "maxLength" | "pattern";
type DynamicLabelPosition = "top" | "side";
type DynamicFieldColSpan = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
interface DynamicFieldOption {
    label: string;
    value: unknown;
}
interface DynamicEnumOptionConfig {
    enumValue: string | number;
    label: string;
    icon?: string;
}
interface DynamicEnumConfig {
    values: Record<string, string | number>;
    showIcons?: boolean;
    options: DynamicEnumOptionConfig[];
}
type DynamicImageVariant = "square" | "avatar";
interface DynamicImageConfig {
    variant: DynamicImageVariant;
    accept?: string;
    emptyLabel?: string;
    changeLabel?: string;
}
interface DynamicMoneyConfig {
    currency?: string;
    locale?: string;
    mode?: "currency" | "decimal";
    currencyDisplay?: "symbol" | "code" | "name";
    minFractionDigits?: number;
    maxFractionDigits?: number;
    prefix?: string;
    suffix?: string;
}
interface DynamicPercentConfig {
    minFractionDigits?: number;
    maxFractionDigits?: number;
    prefix?: string;
    suffix?: string;
}
interface DynamicDateConfig {
    dateFormat?: string;
    placeholder?: string;
    showIcon?: boolean;
    utcMode?: "startOfDay";
}
interface DynamicFieldAppearanceConfig {
    borderColor?: string;
    hoverBorderColor?: string;
    focusBorderColor?: string;
    invalidBorderColor?: string;
    backgroundColor?: string;
    textColor?: string;
    placeholderColor?: string;
    focusRingColor?: string;
    borderRadius?: string;
}
interface DynamicValidatorConfig {
    type: DynamicValidatorType;
    value?: number | string | RegExp;
    message?: string;
}
interface DynamicErrorMessageContext {
    field: DynamicFieldConfig;
    errorKey: string;
    errorValue: unknown;
    errors: ValidationErrors;
}
type DynamicErrorTranslationValue = string | ((context: DynamicErrorMessageContext) => string);
type DynamicErrorTranslations = Record<string, DynamicErrorTranslationValue>;
interface DynamicFieldConfig {
    name: string;
    type: DynamicFieldType;
    label: string;
    /** Quantidade de colunas ocupadas no grid de 12 colunas. O padrão é 6 (50%). */
    colSpan?: DynamicFieldColSpan;
    labelPosition?: DynamicLabelPosition;
    placeholder?: string;
    inputType?: "text" | "password" | "email" | "search";
    hint?: string;
    quickHint?: string;
    initialValue?: unknown;
    disabled?: boolean;
    readonly?: boolean;
    hidden?: boolean;
    inputId?: string;
    options?: DynamicFieldOption[];
    optionLayout?: DynamicOptionLayout;
    enumConfig?: DynamicEnumConfig;
    imageConfig?: DynamicImageConfig;
    moneyConfig?: DynamicMoneyConfig;
    percentConfig?: DynamicPercentConfig;
    dateConfig?: DynamicDateConfig;
    appearance?: DynamicFieldAppearanceConfig;
    validators?: DynamicValidatorConfig[];
    controlValidators?: ValidatorFn | ValidatorFn[] | null;
    controlOptions?: AbstractControlOptions | null;
    cssClass?: string;
}

declare class DynamicFieldComponent implements OnDestroy {
    private readonly changeDetectorRef;
    form: FormGroup;
    field: DynamicFieldConfig;
    errorTranslations: DynamicErrorTranslations;
    private readonly objectUrlByFieldName;
    private controlSubscription?;
    private cachedFieldClassList;
    private cachedOptionGroupClassList;
    private cachedEnumOptions;
    private cachedAppearanceStyleVars;
    private cachedPreviewSource;
    private cachedDateInputValue;
    constructor(changeDetectorRef: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    get fieldClassList(): string[];
    get isSideLabel(): boolean;
    get columnSpan(): DynamicFieldColSpan;
    get isRequired(): boolean;
    get showPrimaryLabel(): boolean;
    get isCheckboxGroup(): boolean;
    get optionGroupClassList(): string[];
    get errorMessage(): string | null;
    get enumOptions(): Array<DynamicFieldOption & {
        icon?: string;
    }>;
    get appearanceStyleVars(): Record<string, string>;
    get showEnumIcons(): boolean;
    get previewSource(): string | null;
    get imageVariantClass(): string;
    get dateInputValue(): Date | null;
    get resolvedMoneyMode(): "currency" | "decimal";
    get checkboxGroupValue(): unknown[];
    onCheckboxGroupModelChange(value: unknown): void;
    onImageSelected(event: Event): void;
    onDateSelected(value: Date | null): void;
    ngOnDestroy(): void;
    private bindControl;
    private refreshControlDerivedState;
    private buildEnumOptions;
    private buildAppearanceStyleVars;
    private assignAppearanceVar;
    private resolvePreviewSource;
    private resolveControl;
    private resolveEnumValues;
    resolveOptionInputId(index: number): string;
    private isPreviewObject;
    private ensureObjectUrl;
    private revokeObjectUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynamicFieldComponent, "pfu-dynamic-field", never, { "form": { "alias": "form"; "required": true; }; "field": { "alias": "field"; "required": true; }; "errorTranslations": { "alias": "errorTranslations"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DynamicFormBuilderService {
    buildForm(fields: DynamicFieldConfig[]): FormGroup;
    ensureControls(form: FormGroup, fields: DynamicFieldConfig[]): FormGroup;
    patchInitialValues(form: FormGroup, fields: DynamicFieldConfig[]): void;
    private createControl;
    private resolveInitialValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormBuilderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicFormBuilderService>;
}

declare class DynamicFormComponent implements OnChanges {
    private readonly formBuilder;
    form?: FormGroup;
    fields: DynamicFieldConfig[];
    errorTranslations: DynamicErrorTranslations;
    resolvedForm: FormGroup;
    constructor(formBuilder: DynamicFormBuilderService);
    ngOnChanges(changes: SimpleChanges): void;
    trackByFieldName(_: number, field: DynamicFieldConfig): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynamicFormComponent, "pfu-dynamic-form", never, { "form": { "alias": "form"; "required": false; }; "fields": { "alias": "fields"; "required": true; }; "errorTranslations": { "alias": "errorTranslations"; "required": false; }; }, {}, never, never, true, never>;
}

declare class EmptyStateComponent {
    message: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateComponent, "pfu-empty-state", never, { "message": { "alias": "message"; "required": true; }; }, {}, never, never, true, never>;
}

interface BreadcrumbItem {
    label: string;
    icon?: string;
    url?: string;
}
declare class BreadcrumbComponent implements OnInit, OnDestroy {
    private readonly router;
    private readonly activatedRoute;
    private readonly destroy$;
    readonly items: i0.WritableSignal<BreadcrumbItem[]>;
    readonly pageTitle: i0.WritableSignal<string>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    private updateItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "pfu-breadcrumb", never, {}, {}, never, ["[breadcrumb-actions]"], true, never>;
}

declare class LoadingDirective implements OnChanges, OnDestroy {
    isLoading: boolean;
    private readonly documentRef;
    private readonly elementRef;
    private readonly renderer;
    private overlayElement?;
    private spinnerElement?;
    private previousPosition?;
    private positionManagedByDirective;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private attachOverlay;
    private detachOverlay;
    private ensureOverlayStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LoadingDirective, "[pfuLoading]", never, { "isLoading": { "alias": "pfuLoading"; "required": false; }; }, {}, never, never, true, never>;
}

declare function utcDateNotBeforeTodayValidator(): ValidatorFn;
declare function utcDateNotAfterTodayValidator(): ValidatorFn;
declare function utcDateMinValidator(minDate: string | Date): ValidatorFn;
declare function utcDateMaxValidator(maxDate: string | Date): ValidatorFn;

declare function toUtcStartOfDayIso(value: Date): string;
declare function parseUtcDateValue(value: unknown): Date | null;
declare function toUtcDayStamp(value: unknown): number | null;
declare function utcTodayStamp(): number;

declare const defaultDynamicErrorTranslations: DynamicErrorTranslations;
declare function resolveErrorMessage(field: DynamicFieldConfig, errors: ValidationErrors | null | undefined, translations?: DynamicErrorTranslations): string | null;

declare function mapValidators(validators?: DynamicValidatorConfig[]): ValidatorFn[];

export { BreadcrumbComponent, DynamicFieldComponent, DynamicFormBuilderService, DynamicFormComponent, EmptyStateComponent, LoadingDirective, defaultDynamicErrorTranslations, mapValidators, parseUtcDateValue, resolveErrorMessage, toUtcDayStamp, toUtcStartOfDayIso, utcDateMaxValidator, utcDateMinValidator, utcDateNotAfterTodayValidator, utcDateNotBeforeTodayValidator, utcTodayStamp };
export type { BreadcrumbItem, DynamicDateConfig, DynamicEnumConfig, DynamicEnumOptionConfig, DynamicErrorMessageContext, DynamicErrorTranslationValue, DynamicErrorTranslations, DynamicFieldAppearanceConfig, DynamicFieldColSpan, DynamicFieldConfig, DynamicFieldOption, DynamicFieldType, DynamicImageConfig, DynamicImageVariant, DynamicLabelPosition, DynamicMoneyConfig, DynamicOptionLayout, DynamicPercentConfig, DynamicValidatorConfig, DynamicValidatorType };
