import * as i1 from '@angular/common';
import { CommonModule, DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { Input, ChangeDetectionStrategy, Component, Injectable, inject, signal, ElementRef, Renderer2, Directive } from '@angular/core';
import * as i2 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, Validators, FormGroup, FormControl } from '@angular/forms';
import * as i3 from 'primeng/checkbox';
import { CheckboxModule } from 'primeng/checkbox';
import * as i4 from 'primeng/datepicker';
import { DatePickerModule } from 'primeng/datepicker';
import * as i5 from 'primeng/inputnumber';
import { InputNumberModule } from 'primeng/inputnumber';
import * as i6 from 'primeng/inputtext';
import { InputTextModule } from 'primeng/inputtext';
import * as i7 from 'primeng/radiobutton';
import { RadioButtonModule } from 'primeng/radiobutton';
import * as i8 from 'primeng/select';
import { SelectModule } from 'primeng/select';
import * as i9 from 'primeng/textarea';
import { TextareaModule } from 'primeng/textarea';
import * as i10 from 'primeng/tooltip';
import { TooltipModule } from 'primeng/tooltip';
import { Router, ActivatedRoute, NavigationEnd, RouterLink } from '@angular/router';
import { Subject, filter, takeUntil } from 'rxjs';

const defaultDynamicErrorTranslations = {
    required: 'Campo obrigatorio.',
    email: 'Informe um e-mail valido.',
    min: ({ errorValue }) => `Valor minimo permitido: ${readNumericErrorValue(errorValue, 'min')}.`,
    max: ({ errorValue }) => `Valor maximo permitido: ${readNumericErrorValue(errorValue, 'max')}.`,
    minlength: ({ errorValue }) => `Quantidade minima de caracteres: ${readNumericErrorValue(errorValue, 'requiredLength')}.`,
    maxlength: ({ errorValue }) => `Quantidade maxima de caracteres: ${readNumericErrorValue(errorValue, 'requiredLength')}.`,
    pattern: 'Formato invalido.',
    utcDateNotBeforeToday: 'A data nao pode ser inferior a hoje.',
    utcDateNotAfterToday: 'A data nao pode ser superior a hoje.',
    utcDateMin: 'A data informada e inferior ao minimo permitido.',
    utcDateMax: 'A data informada e superior ao maximo permitido.'
};
function resolveErrorMessage(field, errors, translations = defaultDynamicErrorTranslations) {
    if (!errors) {
        return null;
    }
    const [firstKey] = Object.keys(errors);
    if (!firstKey) {
        return null;
    }
    const customMessage = field.validators?.find((validator) => {
        const normalizedType = validator.type === 'minLength' ? 'minlength' :
            validator.type === 'maxLength' ? 'maxlength' :
                validator.type;
        return normalizedType === firstKey;
    })?.message;
    if (customMessage) {
        return customMessage;
    }
    const translation = translations[firstKey];
    if (typeof translation === 'function') {
        return translation({
            field,
            errorKey: firstKey,
            errorValue: errors[firstKey],
            errors
        });
    }
    return translation ?? 'Campo invalido.';
}
function readNumericErrorValue(errorValue, key) {
    if (typeof errorValue === 'object' && errorValue !== null && key in errorValue) {
        const value = errorValue[key];
        if (typeof value === 'number' || typeof value === 'string') {
            return value;
        }
    }
    return '';
}

function toUtcStartOfDayIso(value) {
    const utcDate = new Date(Date.UTC(value.getFullYear(), value.getMonth(), value.getDate(), 0, 0, 0, 0));
    return utcDate.toISOString();
}
function parseUtcDateValue(value) {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
        return new Date(value.getFullYear(), value.getMonth(), value.getDate());
    }
    if (typeof value !== 'string' || !value) {
        return null;
    }
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) {
        return null;
    }
    return new Date(parsed.getUTCFullYear(), parsed.getUTCMonth(), parsed.getUTCDate());
}
function toUtcDayStamp(value) {
    const parsed = parseUtcDateValue(value);
    if (!parsed) {
        return null;
    }
    return Date.UTC(parsed.getFullYear(), parsed.getMonth(), parsed.getDate(), 0, 0, 0, 0);
}
function utcTodayStamp() {
    const now = new Date();
    return Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0, 0);
}

class DynamicFieldComponent {
    changeDetectorRef;
    form;
    field;
    errorTranslations = defaultDynamicErrorTranslations;
    objectUrlByFieldName = new Map();
    controlSubscription;
    cachedFieldClassList = [];
    cachedOptionGroupClassList = [];
    cachedEnumOptions = [];
    cachedAppearanceStyleVars = {};
    cachedPreviewSource = null;
    cachedDateInputValue = null;
    constructor(changeDetectorRef) {
        this.changeDetectorRef = changeDetectorRef;
    }
    ngOnChanges(changes) {
        if (changes["field"]) {
            this.cachedFieldClassList = [
                "pfu-field",
                this.isSideLabel ? "pfu-field-side" : "pfu-field-top",
                ...(this.field.cssClass ? [this.field.cssClass] : []),
            ];
            this.cachedOptionGroupClassList = [
                "pfu-choice-group",
                this.field.optionLayout === "horizontal"
                    ? "pfu-choice-group-horizontal"
                    : "pfu-choice-group-vertical",
            ];
            this.cachedEnumOptions = this.buildEnumOptions();
            this.cachedAppearanceStyleVars = this.buildAppearanceStyleVars(this.field.appearance);
        }
        if (changes["form"] || changes["field"]) {
            this.bindControl();
            this.refreshControlDerivedState();
        }
    }
    get fieldClassList() {
        return this.cachedFieldClassList;
    }
    get isSideLabel() {
        return this.field.labelPosition === "side";
    }
    get columnSpan() {
        return this.field.colSpan ?? 6;
    }
    get isRequired() {
        return (this.field.validators?.some((validator) => validator.type === "required") ?? false);
    }
    get showPrimaryLabel() {
        return this.field.type !== "checkbox" || this.isCheckboxGroup;
    }
    get isCheckboxGroup() {
        return (this.field.type === "checkbox" && Boolean(this.field.options?.length));
    }
    get optionGroupClassList() {
        return this.cachedOptionGroupClassList;
    }
    get errorMessage() {
        const control = this.form.get(this.field.name);
        if (!control || !control.invalid || !(control.dirty || control.touched)) {
            return null;
        }
        return resolveErrorMessage(this.field, control.errors, this.errorTranslations);
    }
    get enumOptions() {
        return this.cachedEnumOptions;
    }
    get appearanceStyleVars() {
        return this.cachedAppearanceStyleVars;
    }
    get showEnumIcons() {
        return (this.field.type === "enum" && Boolean(this.field.enumConfig?.showIcons));
    }
    get previewSource() {
        return this.cachedPreviewSource;
    }
    get imageVariantClass() {
        return this.field.imageConfig?.variant === "avatar"
            ? "pfu-image-preview-avatar"
            : "pfu-image-preview-square";
    }
    get dateInputValue() {
        return this.cachedDateInputValue;
    }
    get resolvedMoneyMode() {
        return this.field.moneyConfig?.mode ?? "currency";
    }
    get checkboxGroupValue() {
        const controlValue = this.form.get(this.field.name)?.value;
        return Array.isArray(controlValue) ? controlValue : [];
    }
    onCheckboxGroupModelChange(value) {
        const control = this.form.get(this.field.name);
        if (!control) {
            return;
        }
        control.setValue(Array.isArray(value) ? value : []);
        control.markAsDirty();
        control.markAsTouched();
        control.updateValueAndValidity();
    }
    onImageSelected(event) {
        const input = event.target;
        const file = input.files?.[0] ?? null;
        const control = this.form.get(this.field.name);
        if (!control) {
            return;
        }
        this.revokeObjectUrl(this.field.name);
        control.setValue(file);
        control.markAsDirty();
        control.markAsTouched();
        control.updateValueAndValidity();
        this.refreshControlDerivedState();
    }
    onDateSelected(value) {
        const control = this.form.get(this.field.name);
        if (!control) {
            return;
        }
        control.setValue(value ? toUtcStartOfDayIso(value) : null);
        control.markAsDirty();
        control.markAsTouched();
        control.updateValueAndValidity();
        this.refreshControlDerivedState();
    }
    ngOnDestroy() {
        this.controlSubscription?.unsubscribe();
        Array.from(this.objectUrlByFieldName.keys()).forEach((fieldName) => {
            this.revokeObjectUrl(fieldName);
        });
    }
    bindControl() {
        this.controlSubscription?.unsubscribe();
        const control = this.resolveControl();
        if (!control) {
            return;
        }
        this.controlSubscription = control.valueChanges.subscribe(() => {
            this.refreshControlDerivedState();
        });
    }
    refreshControlDerivedState() {
        const controlValue = this.resolveControl()?.value;
        if (this.field.type === "image") {
            this.cachedPreviewSource = this.resolvePreviewSource(controlValue);
        }
        else {
            this.cachedPreviewSource = null;
        }
        if (this.field.type === "date") {
            this.cachedDateInputValue = parseUtcDateValue(controlValue);
        }
        else {
            this.cachedDateInputValue = null;
        }
        this.changeDetectorRef.markForCheck();
    }
    buildEnumOptions() {
        if (this.field.type !== "enum" || !this.field.enumConfig) {
            return [];
        }
        const enumEntries = new Set(this.resolveEnumValues(this.field.enumConfig.values));
        return this.field.enumConfig.options
            .filter((option) => enumEntries.has(option.enumValue))
            .map((option) => ({
            label: option.label,
            value: option.enumValue,
            icon: option.icon,
        }));
    }
    buildAppearanceStyleVars(appearance) {
        if (!appearance) {
            return {};
        }
        const styleVars = {};
        this.assignAppearanceVar(styleVars, appearance.borderColor, [
            "--p-inputtext-border-color",
            "--p-textarea-border-color",
            "--p-select-border-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.hoverBorderColor, [
            "--p-inputtext-hover-border-color",
            "--p-textarea-hover-border-color",
            "--p-select-hover-border-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.focusBorderColor, [
            "--p-inputtext-focus-border-color",
            "--p-textarea-focus-border-color",
            "--p-select-focus-border-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.invalidBorderColor, [
            "--p-inputtext-invalid-border-color",
            "--p-textarea-invalid-border-color",
            "--p-select-invalid-border-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.backgroundColor, [
            "--p-inputtext-background",
            "--p-textarea-background",
            "--p-select-background",
        ]);
        this.assignAppearanceVar(styleVars, appearance.textColor, [
            "--p-inputtext-color",
            "--p-textarea-color",
            "--p-select-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.placeholderColor, [
            "--p-inputtext-placeholder-color",
            "--p-textarea-placeholder-color",
            "--p-select-placeholder-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.focusRingColor, [
            "--p-inputtext-focus-ring-color",
            "--p-textarea-focus-ring-color",
            "--p-select-focus-ring-color",
            "--p-checkbox-focus-ring-color",
            "--p-radiobutton-focus-ring-color",
        ]);
        this.assignAppearanceVar(styleVars, appearance.borderRadius, [
            "--p-inputtext-border-radius",
            "--p-textarea-border-radius",
            "--p-select-border-radius",
        ]);
        return styleVars;
    }
    assignAppearanceVar(styleVars, value, variableNames) {
        if (!value) {
            return;
        }
        variableNames.forEach((variableName) => {
            styleVars[variableName] = value;
        });
    }
    resolvePreviewSource(controlValue) {
        if (typeof controlValue === "string" && controlValue) {
            return controlValue;
        }
        if (this.isPreviewObject(controlValue)) {
            return controlValue.previewUrl;
        }
        if (controlValue instanceof File) {
            return this.ensureObjectUrl(this.field.name, controlValue);
        }
        return null;
    }
    resolveControl() {
        return this.form?.get(this.field.name) ?? null;
    }
    resolveEnumValues(enumValues) {
        const values = Object.values(enumValues);
        return values.filter((value) => {
            if (typeof value === "number") {
                return true;
            }
            return !(value in enumValues);
        });
    }
    resolveOptionInputId(index) {
        return `${this.field.inputId ?? this.field.name}-${index}`;
    }
    isPreviewObject(value) {
        return (typeof value === "object" &&
            value !== null &&
            "previewUrl" in value &&
            typeof value.previewUrl === "string");
    }
    ensureObjectUrl(fieldName, file) {
        const existingUrl = this.objectUrlByFieldName.get(fieldName);
        if (existingUrl) {
            return existingUrl;
        }
        if (typeof URL === "undefined" ||
            typeof URL.createObjectURL !== "function") {
            return null;
        }
        const objectUrl = URL.createObjectURL(file);
        this.objectUrlByFieldName.set(fieldName, objectUrl);
        return objectUrl;
    }
    revokeObjectUrl(fieldName) {
        const objectUrl = this.objectUrlByFieldName.get(fieldName);
        if (!objectUrl ||
            typeof URL === "undefined" ||
            typeof URL.revokeObjectURL !== "function") {
            return;
        }
        URL.revokeObjectURL(objectUrl);
        this.objectUrlByFieldName.delete(fieldName);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFieldComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.7", type: DynamicFieldComponent, isStandalone: true, selector: "pfu-dynamic-field", inputs: { form: "form", field: "field", errorTranslations: "errorTranslations" }, host: { styleAttribute: "display: contents;", classAttribute: "pfu-dynamic-field-host" }, usesOnChanges: true, ngImport: i0, template: `
    <div
      [ngClass]="fieldClassList"
      [ngStyle]="appearanceStyleVars"
      [style.--pfu-field-column-span]="columnSpan"
      [formGroup]="form"
      *ngIf="!field.hidden"
    >
      <div class="pfu-label-wrapper" *ngIf="showPrimaryLabel">
        <label class="pfu-label" [attr.for]="field.inputId ?? field.name">
          <span class="pfu-required-mark" *ngIf="isRequired" aria-hidden="true"
            >*</span
          >
          <span>{{ field.label }}</span>
        </label>
        <button
          *ngIf="field.quickHint"
          class="pfu-info-button"
          type="button"
          [pTooltip]="field.quickHint"
          tooltipPosition="top"
          aria-label="Ajuda do campo"
        >
          <span class="pi pi-info-circle" aria-hidden="true"></span>
        </button>
      </div>

      <div class="pfu-control">
        <ng-container [ngSwitch]="field.type">
          <input
            *ngSwitchCase="'text'"
            pInputText
            [id]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [type]="field.inputType ?? 'text'"
            [readOnly]="field.readonly ?? false"
          />

          <p-input-number
            *ngSwitchCase="'number'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [useGrouping]="false"
          />

          <p-input-number
            *ngSwitchCase="'money'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [mode]="resolvedMoneyMode"
            [currency]="field.moneyConfig?.currency ?? 'BRL'"
            [locale]="field.moneyConfig?.locale ?? 'pt-BR'"
            [currencyDisplay]="field.moneyConfig?.currencyDisplay ?? 'symbol'"
            [minFractionDigits]="field.moneyConfig?.minFractionDigits ?? 2"
            [maxFractionDigits]="field.moneyConfig?.maxFractionDigits ?? 2"
            [prefix]="field.moneyConfig?.prefix"
            [suffix]="field.moneyConfig?.suffix"
          />

          <p-input-number
            *ngSwitchCase="'percent'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [mode]="'decimal'"
            [minFractionDigits]="field.percentConfig?.minFractionDigits ?? 2"
            [maxFractionDigits]="field.percentConfig?.maxFractionDigits ?? 2"
            [prefix]="field.percentConfig?.prefix"
            [suffix]="field.percentConfig?.suffix ?? '%'"
          />

          <textarea
            *ngSwitchCase="'textarea'"
            pTextarea
            [id]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readOnly]="field.readonly ?? false"
            rows="4"
          ></textarea>

          <p-select
            *ngSwitchCase="'select'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [options]="field.options ?? []"
            [placeholder]="field.placeholder ?? 'Selecione'"
            optionLabel="label"
            optionValue="value"
          />

          <p-select
            *ngSwitchCase="'enum'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [options]="enumOptions"
            [placeholder]="field.placeholder ?? 'Selecione'"
            optionLabel="label"
            optionValue="value"
          >
            <ng-template #selectedItem let-selectedOption>
              <div class="pfu-option" *ngIf="selectedOption">
                <span
                  *ngIf="showEnumIcons && selectedOption.icon"
                  [class]="selectedOption.icon"
                  aria-hidden="true"
                ></span>
                <span>{{ selectedOption.label }}</span>
              </div>
              <span class="pfu-placeholder" *ngIf="!selectedOption">
                {{ field.placeholder ?? "Selecione" }}
              </span>
            </ng-template>

            <ng-template #item let-option>
              <div class="pfu-option">
                <span
                  *ngIf="showEnumIcons && option.icon"
                  [class]="option.icon"
                  aria-hidden="true"
                ></span>
                <span>{{ option.label }}</span>
              </div>
            </ng-template>
          </p-select>

          <p-datepicker
            *ngSwitchCase="'date'"
            [inputId]="field.inputId ?? field.name"
            [ngModel]="dateInputValue"
            [ngModelOptions]="{ standalone: true }"
            (ngModelChange)="onDateSelected($event)"
            [placeholder]="
              field.dateConfig?.placeholder ?? field.placeholder ?? ''
            "
            [dateFormat]="field.dateConfig?.dateFormat ?? 'dd/mm/yy'"
            [showIcon]="field.dateConfig?.showIcon ?? true"
          />

          <div [ngClass]="optionGroupClassList" *ngSwitchCase="'radio'">
            <div
              class="pfu-choice-item"
              *ngFor="
                let option of field.options ?? [];
                let optionIndex = index
              "
            >
              <p-radio-button
                [inputId]="resolveOptionInputId(optionIndex)"
                [formControlName]="field.name"
                [value]="option.value"
              />
              <label [attr.for]="resolveOptionInputId(optionIndex)">{{
                option.label
              }}</label>
            </div>
          </div>

          <div class="pfu-image-field" *ngSwitchCase="'image'">
            <div
              [ngClass]="[
                'pfu-image-preview',
                imageVariantClass,
                previewSource
                  ? 'pfu-image-preview-filled'
                  : 'pfu-image-preview-empty',
              ]"
            >
              <img
                *ngIf="previewSource"
                [src]="previewSource"
                [alt]="field.label"
                class="pfu-image-preview-media"
              />
              <span class="pfu-image-preview-text" *ngIf="!previewSource">
                {{
                  field.imageConfig?.emptyLabel ?? "Nenhuma imagem selecionada"
                }}
              </span>
            </div>

            <label
              class="pfu-image-upload-button"
              [attr.for]="field.inputId ?? field.name"
            >
              {{ field.imageConfig?.changeLabel ?? "Selecionar imagem" }}
            </label>

            <input
              class="pfu-image-input"
              type="file"
              [id]="field.inputId ?? field.name"
              [accept]="field.imageConfig?.accept ?? 'image/*'"
              [disabled]="field.disabled ?? false"
              (change)="onImageSelected($event)"
            />
          </div>

          <div
            [ngClass]="isCheckboxGroup ? optionGroupClassList : 'pfu-checkbox'"
            *ngSwitchCase="'checkbox'"
          >
            <ng-container *ngIf="isCheckboxGroup">
              <div
                class="pfu-choice-item"
                *ngFor="
                  let option of field.options ?? [];
                  let optionIndex = index
                "
              >
                <p-checkbox
                  [inputId]="resolveOptionInputId(optionIndex)"
                  [value]="option.value"
                  [binary]="false"
                  [ngModel]="checkboxGroupValue"
                  [ngModelOptions]="{ standalone: true }"
                  (ngModelChange)="onCheckboxGroupModelChange($event)"
                />
                <label [attr.for]="resolveOptionInputId(optionIndex)">{{
                  option.label
                }}</label>
              </div>
            </ng-container>

            <ng-container *ngIf="!isCheckboxGroup">
              <p-checkbox
                [inputId]="field.inputId ?? field.name"
                [formControlName]="field.name"
                [binary]="true"
              />
              <label [attr.for]="field.inputId ?? field.name">
                <span
                  class="pfu-required-mark"
                  *ngIf="isRequired"
                  aria-hidden="true"
                  >*</span
                >
                <span>{{ field.placeholder ?? field.label }}</span>
              </label>
              <button
                *ngIf="field.quickHint"
                class="pfu-info-button"
                type="button"
                [pTooltip]="field.quickHint"
                tooltipPosition="top"
                aria-label="Ajuda do campo"
              >
                <span class="pi pi-info-circle" aria-hidden="true"></span>
              </button>
            </ng-container>
          </div>
        </ng-container>

        <small class="pfu-hint" *ngIf="field.hint">{{ field.hint }}</small>
        <small class="pfu-error" *ngIf="errorMessage">{{ errorMessage }}</small>
      </div>
    </div>
  `, isInline: true, styles: [".pfu-label-wrapper{display:inline-flex;align-items:center;gap:.35rem}.pfu-field{display:flex;align-items:flex-start;gap:.5rem;min-width:0;grid-column:span var(--pfu-field-column-span, 6)}.pfu-field-top{flex-direction:column}.pfu-field-side{flex-direction:row}@media(max-width:767px){.pfu-field{grid-column:span 12}.pfu-field-side{flex-direction:column}}.pfu-field-side .pfu-label-wrapper{width:12rem;min-height:2.5rem;padding-top:.5rem}.pfu-control{display:flex;flex:1 1 auto;flex-direction:column;gap:.5rem;width:100%}.pfu-label{display:inline-flex;align-items:center;gap:.25rem;font-weight:600}.pfu-required-mark{color:#b91c1c;font-weight:700}.pfu-info-button{display:inline-flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;padding:0;border:0;background:transparent;color:#475569;cursor:pointer}.pfu-info-button:hover{color:#0f172a}.pfu-checkbox{display:flex;align-items:center;gap:.5rem}.pfu-choice-group{display:flex;gap:.75rem}.pfu-choice-group-vertical{flex-direction:column}.pfu-choice-group-horizontal{flex-direction:row;flex-wrap:wrap}.pfu-choice-item{display:inline-flex;align-items:center;gap:.5rem}.pfu-image-field{display:flex;flex-direction:column;gap:.75rem}.pfu-image-preview{display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f8fafc;border:1px dashed #cbd5e1}.pfu-image-preview-square{width:9rem;height:9rem;border-radius:.75rem}.pfu-image-preview-avatar{width:6rem;height:6rem;border-radius:9999px}.pfu-image-preview-filled{border-style:solid}.pfu-image-preview-media{width:100%;height:100%;object-fit:cover}.pfu-image-preview-text{padding:.75rem;text-align:center;font-size:.875rem;color:#64748b}.pfu-image-upload-button{display:inline-flex;align-items:center;justify-content:center;min-height:2.5rem;width:fit-content;padding:.5rem .875rem;border-radius:.5rem;background:#0f172a;color:#fff;cursor:pointer}.pfu-image-input{display:none}.pfu-option{display:inline-flex;align-items:center;gap:.5rem}.pfu-placeholder{color:#64748b}.pfu-field-side .pfu-checkbox{min-height:2.5rem}.pfu-hint{color:#64748b}.pfu-error{color:#b91c1c}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i1.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i1.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: CheckboxModule }, { kind: "component", type: i3.Checkbox, selector: "p-checkbox, p-check-box", inputs: ["value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: DatePickerModule }, { kind: "component", type: i4.DatePicker, selector: "p-datepicker, p-date-picker", inputs: ["iconDisplay", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }, { kind: "ngmodule", type: InputNumberModule }, { kind: "component", type: i5.InputNumber, selector: "p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i6.InputText, selector: "[pInputText]", inputs: ["hostName", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: RadioButtonModule }, { kind: "component", type: i7.RadioButton, selector: "p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i8.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "multiple", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: TextareaModule }, { kind: "directive", type: i9.Textarea, selector: "[pTextarea], [pInputTextarea]", inputs: ["pTextareaPT", "pTextareaUnstyled", "autoResize", "pSize", "variant", "fluid", "invalid"], outputs: ["onResize"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i10.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "pTooltipPT", "pTooltipUnstyled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: "pfu-dynamic-field", standalone: true, host: {
                        class: "pfu-dynamic-field-host",
                        style: "display: contents;",
                    }, imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        CheckboxModule,
                        DatePickerModule,
                        InputNumberModule,
                        InputTextModule,
                        RadioButtonModule,
                        SelectModule,
                        TextareaModule,
                        TooltipModule,
                    ], template: `
    <div
      [ngClass]="fieldClassList"
      [ngStyle]="appearanceStyleVars"
      [style.--pfu-field-column-span]="columnSpan"
      [formGroup]="form"
      *ngIf="!field.hidden"
    >
      <div class="pfu-label-wrapper" *ngIf="showPrimaryLabel">
        <label class="pfu-label" [attr.for]="field.inputId ?? field.name">
          <span class="pfu-required-mark" *ngIf="isRequired" aria-hidden="true"
            >*</span
          >
          <span>{{ field.label }}</span>
        </label>
        <button
          *ngIf="field.quickHint"
          class="pfu-info-button"
          type="button"
          [pTooltip]="field.quickHint"
          tooltipPosition="top"
          aria-label="Ajuda do campo"
        >
          <span class="pi pi-info-circle" aria-hidden="true"></span>
        </button>
      </div>

      <div class="pfu-control">
        <ng-container [ngSwitch]="field.type">
          <input
            *ngSwitchCase="'text'"
            pInputText
            [id]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [type]="field.inputType ?? 'text'"
            [readOnly]="field.readonly ?? false"
          />

          <p-input-number
            *ngSwitchCase="'number'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [useGrouping]="false"
          />

          <p-input-number
            *ngSwitchCase="'money'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [mode]="resolvedMoneyMode"
            [currency]="field.moneyConfig?.currency ?? 'BRL'"
            [locale]="field.moneyConfig?.locale ?? 'pt-BR'"
            [currencyDisplay]="field.moneyConfig?.currencyDisplay ?? 'symbol'"
            [minFractionDigits]="field.moneyConfig?.minFractionDigits ?? 2"
            [maxFractionDigits]="field.moneyConfig?.maxFractionDigits ?? 2"
            [prefix]="field.moneyConfig?.prefix"
            [suffix]="field.moneyConfig?.suffix"
          />

          <p-input-number
            *ngSwitchCase="'percent'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readonly]="field.readonly ?? false"
            [mode]="'decimal'"
            [minFractionDigits]="field.percentConfig?.minFractionDigits ?? 2"
            [maxFractionDigits]="field.percentConfig?.maxFractionDigits ?? 2"
            [prefix]="field.percentConfig?.prefix"
            [suffix]="field.percentConfig?.suffix ?? '%'"
          />

          <textarea
            *ngSwitchCase="'textarea'"
            pTextarea
            [id]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [placeholder]="field.placeholder ?? ''"
            [readOnly]="field.readonly ?? false"
            rows="4"
          ></textarea>

          <p-select
            *ngSwitchCase="'select'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [options]="field.options ?? []"
            [placeholder]="field.placeholder ?? 'Selecione'"
            optionLabel="label"
            optionValue="value"
          />

          <p-select
            *ngSwitchCase="'enum'"
            [inputId]="field.inputId ?? field.name"
            [formControlName]="field.name"
            [options]="enumOptions"
            [placeholder]="field.placeholder ?? 'Selecione'"
            optionLabel="label"
            optionValue="value"
          >
            <ng-template #selectedItem let-selectedOption>
              <div class="pfu-option" *ngIf="selectedOption">
                <span
                  *ngIf="showEnumIcons && selectedOption.icon"
                  [class]="selectedOption.icon"
                  aria-hidden="true"
                ></span>
                <span>{{ selectedOption.label }}</span>
              </div>
              <span class="pfu-placeholder" *ngIf="!selectedOption">
                {{ field.placeholder ?? "Selecione" }}
              </span>
            </ng-template>

            <ng-template #item let-option>
              <div class="pfu-option">
                <span
                  *ngIf="showEnumIcons && option.icon"
                  [class]="option.icon"
                  aria-hidden="true"
                ></span>
                <span>{{ option.label }}</span>
              </div>
            </ng-template>
          </p-select>

          <p-datepicker
            *ngSwitchCase="'date'"
            [inputId]="field.inputId ?? field.name"
            [ngModel]="dateInputValue"
            [ngModelOptions]="{ standalone: true }"
            (ngModelChange)="onDateSelected($event)"
            [placeholder]="
              field.dateConfig?.placeholder ?? field.placeholder ?? ''
            "
            [dateFormat]="field.dateConfig?.dateFormat ?? 'dd/mm/yy'"
            [showIcon]="field.dateConfig?.showIcon ?? true"
          />

          <div [ngClass]="optionGroupClassList" *ngSwitchCase="'radio'">
            <div
              class="pfu-choice-item"
              *ngFor="
                let option of field.options ?? [];
                let optionIndex = index
              "
            >
              <p-radio-button
                [inputId]="resolveOptionInputId(optionIndex)"
                [formControlName]="field.name"
                [value]="option.value"
              />
              <label [attr.for]="resolveOptionInputId(optionIndex)">{{
                option.label
              }}</label>
            </div>
          </div>

          <div class="pfu-image-field" *ngSwitchCase="'image'">
            <div
              [ngClass]="[
                'pfu-image-preview',
                imageVariantClass,
                previewSource
                  ? 'pfu-image-preview-filled'
                  : 'pfu-image-preview-empty',
              ]"
            >
              <img
                *ngIf="previewSource"
                [src]="previewSource"
                [alt]="field.label"
                class="pfu-image-preview-media"
              />
              <span class="pfu-image-preview-text" *ngIf="!previewSource">
                {{
                  field.imageConfig?.emptyLabel ?? "Nenhuma imagem selecionada"
                }}
              </span>
            </div>

            <label
              class="pfu-image-upload-button"
              [attr.for]="field.inputId ?? field.name"
            >
              {{ field.imageConfig?.changeLabel ?? "Selecionar imagem" }}
            </label>

            <input
              class="pfu-image-input"
              type="file"
              [id]="field.inputId ?? field.name"
              [accept]="field.imageConfig?.accept ?? 'image/*'"
              [disabled]="field.disabled ?? false"
              (change)="onImageSelected($event)"
            />
          </div>

          <div
            [ngClass]="isCheckboxGroup ? optionGroupClassList : 'pfu-checkbox'"
            *ngSwitchCase="'checkbox'"
          >
            <ng-container *ngIf="isCheckboxGroup">
              <div
                class="pfu-choice-item"
                *ngFor="
                  let option of field.options ?? [];
                  let optionIndex = index
                "
              >
                <p-checkbox
                  [inputId]="resolveOptionInputId(optionIndex)"
                  [value]="option.value"
                  [binary]="false"
                  [ngModel]="checkboxGroupValue"
                  [ngModelOptions]="{ standalone: true }"
                  (ngModelChange)="onCheckboxGroupModelChange($event)"
                />
                <label [attr.for]="resolveOptionInputId(optionIndex)">{{
                  option.label
                }}</label>
              </div>
            </ng-container>

            <ng-container *ngIf="!isCheckboxGroup">
              <p-checkbox
                [inputId]="field.inputId ?? field.name"
                [formControlName]="field.name"
                [binary]="true"
              />
              <label [attr.for]="field.inputId ?? field.name">
                <span
                  class="pfu-required-mark"
                  *ngIf="isRequired"
                  aria-hidden="true"
                  >*</span
                >
                <span>{{ field.placeholder ?? field.label }}</span>
              </label>
              <button
                *ngIf="field.quickHint"
                class="pfu-info-button"
                type="button"
                [pTooltip]="field.quickHint"
                tooltipPosition="top"
                aria-label="Ajuda do campo"
              >
                <span class="pi pi-info-circle" aria-hidden="true"></span>
              </button>
            </ng-container>
          </div>
        </ng-container>

        <small class="pfu-hint" *ngIf="field.hint">{{ field.hint }}</small>
        <small class="pfu-error" *ngIf="errorMessage">{{ errorMessage }}</small>
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".pfu-label-wrapper{display:inline-flex;align-items:center;gap:.35rem}.pfu-field{display:flex;align-items:flex-start;gap:.5rem;min-width:0;grid-column:span var(--pfu-field-column-span, 6)}.pfu-field-top{flex-direction:column}.pfu-field-side{flex-direction:row}@media(max-width:767px){.pfu-field{grid-column:span 12}.pfu-field-side{flex-direction:column}}.pfu-field-side .pfu-label-wrapper{width:12rem;min-height:2.5rem;padding-top:.5rem}.pfu-control{display:flex;flex:1 1 auto;flex-direction:column;gap:.5rem;width:100%}.pfu-label{display:inline-flex;align-items:center;gap:.25rem;font-weight:600}.pfu-required-mark{color:#b91c1c;font-weight:700}.pfu-info-button{display:inline-flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;padding:0;border:0;background:transparent;color:#475569;cursor:pointer}.pfu-info-button:hover{color:#0f172a}.pfu-checkbox{display:flex;align-items:center;gap:.5rem}.pfu-choice-group{display:flex;gap:.75rem}.pfu-choice-group-vertical{flex-direction:column}.pfu-choice-group-horizontal{flex-direction:row;flex-wrap:wrap}.pfu-choice-item{display:inline-flex;align-items:center;gap:.5rem}.pfu-image-field{display:flex;flex-direction:column;gap:.75rem}.pfu-image-preview{display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f8fafc;border:1px dashed #cbd5e1}.pfu-image-preview-square{width:9rem;height:9rem;border-radius:.75rem}.pfu-image-preview-avatar{width:6rem;height:6rem;border-radius:9999px}.pfu-image-preview-filled{border-style:solid}.pfu-image-preview-media{width:100%;height:100%;object-fit:cover}.pfu-image-preview-text{padding:.75rem;text-align:center;font-size:.875rem;color:#64748b}.pfu-image-upload-button{display:inline-flex;align-items:center;justify-content:center;min-height:2.5rem;width:fit-content;padding:.5rem .875rem;border-radius:.5rem;background:#0f172a;color:#fff;cursor:pointer}.pfu-image-input{display:none}.pfu-option{display:inline-flex;align-items:center;gap:.5rem}.pfu-placeholder{color:#64748b}.pfu-field-side .pfu-checkbox{min-height:2.5rem}.pfu-hint{color:#64748b}.pfu-error{color:#b91c1c}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { form: [{
                type: Input,
                args: [{ required: true }]
            }], field: [{
                type: Input,
                args: [{ required: true }]
            }], errorTranslations: [{
                type: Input
            }] } });

function mapValidators(validators = []) {
    return validators.map((validator) => {
        switch (validator.type) {
            case 'required':
                return Validators.required;
            case 'email':
                return Validators.email;
            case 'min':
                return Validators.min(Number(validator.value ?? 0));
            case 'max':
                return Validators.max(Number(validator.value ?? 0));
            case 'minLength':
                return Validators.minLength(Number(validator.value ?? 0));
            case 'maxLength':
                return Validators.maxLength(Number(validator.value ?? 0));
            case 'pattern':
                return Validators.pattern(String(validator.value ?? ''));
            default:
                return Validators.nullValidator;
        }
    });
}

class DynamicFormBuilderService {
    buildForm(fields) {
        const controls = fields.reduce((acc, field) => {
            acc[field.name] = this.createControl(field);
            return acc;
        }, {});
        return new FormGroup(controls);
    }
    ensureControls(form, fields) {
        fields.forEach((field) => {
            const existingControl = form.get(field.name);
            if (existingControl) {
                return;
            }
            form.addControl(field.name, this.createControl(field));
        });
        return form;
    }
    patchInitialValues(form, fields) {
        const values = fields.reduce((acc, field) => {
            acc[field.name] = field.initialValue ?? null;
            return acc;
        }, {});
        form.patchValue(values);
    }
    createControl(field) {
        return new FormControl({ value: field.initialValue ?? this.resolveInitialValue(field), disabled: field.disabled ?? false }, {
            validators: [
                ...mapValidators(field.validators),
                ...(Array.isArray(field.controlValidators)
                    ? field.controlValidators
                    : field.controlValidators
                        ? [field.controlValidators]
                        : [])
            ],
            ...field.controlOptions
        });
    }
    resolveInitialValue(field) {
        if (field.type === 'checkbox') {
            if (field.options?.length) {
                return [];
            }
            return false;
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFormBuilderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFormBuilderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFormBuilderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class DynamicFormComponent {
    formBuilder;
    form;
    fields = [];
    errorTranslations = defaultDynamicErrorTranslations;
    resolvedForm = new FormGroup({});
    constructor(formBuilder) {
        this.formBuilder = formBuilder;
    }
    ngOnChanges(changes) {
        if (changes["fields"] || changes["form"]) {
            this.resolvedForm = this.form
                ? this.formBuilder.ensureControls(this.form, this.fields)
                : this.formBuilder.buildForm(this.fields);
        }
    }
    trackByFieldName(_, field) {
        return field.name;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFormComponent, deps: [{ token: DynamicFormBuilderService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.7", type: DynamicFormComponent, isStandalone: true, selector: "pfu-dynamic-form", inputs: { form: "form", fields: "fields", errorTranslations: "errorTranslations" }, usesOnChanges: true, ngImport: i0, template: `
    <div class="pfu-form" [formGroup]="resolvedForm">
      <div class="pfu-grid">
        <pfu-dynamic-field
          *ngFor="let field of fields; trackBy: trackByFieldName"
          [form]="resolvedForm"
          [field]="field"
          [errorTranslations]="errorTranslations"
        />
      </div>
    </div>
  `, isInline: true, styles: [".pfu-form{display:flex;flex-direction:column;gap:1rem;width:100%}.pfu-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:.5rem;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: DynamicFieldComponent, selector: "pfu-dynamic-field", inputs: ["form", "field", "errorTranslations"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: DynamicFormComponent, decorators: [{
            type: Component,
            args: [{ selector: "pfu-dynamic-form", standalone: true, imports: [CommonModule, ReactiveFormsModule, DynamicFieldComponent], template: `
    <div class="pfu-form" [formGroup]="resolvedForm">
      <div class="pfu-grid">
        <pfu-dynamic-field
          *ngFor="let field of fields; trackBy: trackByFieldName"
          [form]="resolvedForm"
          [field]="field"
          [errorTranslations]="errorTranslations"
        />
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".pfu-form{display:flex;flex-direction:column;gap:1rem;width:100%}.pfu-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:.5rem;width:100%}\n"] }]
        }], ctorParameters: () => [{ type: DynamicFormBuilderService }], propDecorators: { form: [{
                type: Input
            }], fields: [{
                type: Input,
                args: [{ required: true }]
            }], errorTranslations: [{
                type: Input
            }] } });

class EmptyStateComponent {
    message;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: EmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.7", type: EmptyStateComponent, isStandalone: true, selector: "pfu-empty-state", inputs: { message: "message" }, ngImport: i0, template: `
    <div class="pfu-empty-state" role="status">
      <div class="pfu-empty-state-icon" aria-hidden="true">
        <span class="pi pi-inbox"></span>
      </div>
      <p>{{ message }}</p>
    </div>
  `, isInline: true, styles: [".pfu-empty-state{display:flex;width:100%;flex-direction:column;align-items:center;justify-content:center;padding:1.5rem;border:1px dashed #cbd5e1;border-radius:6px;background:#f8fafc;color:#64748b;text-align:center}.pfu-empty-state-icon{display:flex;height:128px;align-items:center;justify-content:center;color:#0f172a}.pfu-empty-state-icon .pi{font-size:4rem}.pfu-empty-state p{margin:0;font-size:.95rem;font-weight:600}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: EmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: "pfu-empty-state", standalone: true, template: `
    <div class="pfu-empty-state" role="status">
      <div class="pfu-empty-state-icon" aria-hidden="true">
        <span class="pi pi-inbox"></span>
      </div>
      <p>{{ message }}</p>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".pfu-empty-state{display:flex;width:100%;flex-direction:column;align-items:center;justify-content:center;padding:1.5rem;border:1px dashed #cbd5e1;border-radius:6px;background:#f8fafc;color:#64748b;text-align:center}.pfu-empty-state-icon{display:flex;height:128px;align-items:center;justify-content:center;color:#0f172a}.pfu-empty-state-icon .pi{font-size:4rem}.pfu-empty-state p{margin:0;font-size:.95rem;font-weight:600}\n"] }]
        }], propDecorators: { message: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class BreadcrumbComponent {
    router = inject(Router);
    activatedRoute = inject(ActivatedRoute);
    destroy$ = new Subject();
    items = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    pageTitle = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageTitle" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        this.updateItems();
        this.router.events.pipe(filter((event) => event instanceof NavigationEnd), takeUntil(this.destroy$)).subscribe(() => this.updateItems());
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    updateItems() {
        const items = [];
        let route = this.activatedRoute.root;
        let url = '';
        while (route) {
            const segment = route.snapshot.url.map((part) => part.path).join('/');
            if (segment)
                url += `/${segment}`;
            const label = route.snapshot.data['routeTitle'];
            if (typeof label === 'string' && label.trim()) {
                const icon = route.snapshot.data['routeIcon'];
                items.push({
                    label,
                    icon: typeof icon === 'string' && icon.trim() ? icon : undefined,
                    url: route.firstChild ? url || '/' : undefined,
                });
            }
            route = route.firstChild;
        }
        this.items.set(items);
        this.pageTitle.set(items[items.length - 1]?.label ?? '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: BreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.7", type: BreadcrumbComponent, isStandalone: true, selector: "pfu-breadcrumb", ngImport: i0, template: `
    <header class="pfu-page-header">
      <div class="pfu-title-row">
        <h1 class="pfu-page-title">{{ pageTitle() }}</h1>
        <div class="pfu-actions"><ng-content select="[breadcrumb-actions]" /></div>
      </div>

      <nav class="pfu-breadcrumb" aria-label="Breadcrumb">
        <ol>
          @for (item of items(); track item.url ?? item.label; let last = $last) {
            <li>
              @if (!last && item.url) {
                <a [routerLink]="item.url">
                  @if (item.icon) { <span [class]="item.icon" aria-hidden="true"></span> }
                  <span>{{ item.label }}</span>
                </a>
              } @else {
                <span class="pfu-current" [attr.aria-current]="last ? 'page' : null">
                  @if (item.icon) { <span [class]="item.icon" aria-hidden="true"></span> }
                  <span>{{ item.label }}</span>
                </span>
              }
              @if (!last) { <span class="pi pi-chevron-right pfu-separator" aria-hidden="true"></span> }
            </li>
          }
        </ol>
      </nav>
    </header>
  `, isInline: true, styles: [":host{display:block;position:sticky;top:0;z-index:var(--pfu-breadcrumb-z-index, 20);width:100%;margin:0}.pfu-page-header{border:1px solid #cbd5e1;border-radius:6px;background:#ffffffe6;padding:1.25rem;box-shadow:0 18px 38px #0f172a14}.pfu-title-row{display:flex;align-items:center;justify-content:space-between;gap:1rem}.pfu-page-title{margin:0;color:#0f172a;font-size:clamp(1.5rem,3vw,2rem);font-weight:650;letter-spacing:-.035em;line-height:1.2}.pfu-actions{display:flex;align-items:center;justify-content:flex-end;gap:.5rem}.pfu-breadcrumb{margin-top:.8rem}ol{display:flex;flex-wrap:wrap;align-items:center;gap:.45rem;margin:0;padding:0;list-style:none}li,a,.pfu-current{display:inline-flex;align-items:center;gap:.45rem}a{color:#64748b;text-decoration:none;transition:color .15s ease}a:hover{color:#334155}.pfu-current{color:#334155;font-weight:600}.pfu-separator{color:#94a3b8;font-size:.65rem}li{font-size:.82rem}@media(max-width:640px){.pfu-title-row{align-items:flex-start;flex-direction:column}.pfu-actions{width:100%;justify-content:flex-start}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: BreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pfu-breadcrumb', standalone: true, imports: [CommonModule, RouterLink], template: `
    <header class="pfu-page-header">
      <div class="pfu-title-row">
        <h1 class="pfu-page-title">{{ pageTitle() }}</h1>
        <div class="pfu-actions"><ng-content select="[breadcrumb-actions]" /></div>
      </div>

      <nav class="pfu-breadcrumb" aria-label="Breadcrumb">
        <ol>
          @for (item of items(); track item.url ?? item.label; let last = $last) {
            <li>
              @if (!last && item.url) {
                <a [routerLink]="item.url">
                  @if (item.icon) { <span [class]="item.icon" aria-hidden="true"></span> }
                  <span>{{ item.label }}</span>
                </a>
              } @else {
                <span class="pfu-current" [attr.aria-current]="last ? 'page' : null">
                  @if (item.icon) { <span [class]="item.icon" aria-hidden="true"></span> }
                  <span>{{ item.label }}</span>
                </span>
              }
              @if (!last) { <span class="pi pi-chevron-right pfu-separator" aria-hidden="true"></span> }
            </li>
          }
        </ol>
      </nav>
    </header>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;position:sticky;top:0;z-index:var(--pfu-breadcrumb-z-index, 20);width:100%;margin:0}.pfu-page-header{border:1px solid #cbd5e1;border-radius:6px;background:#ffffffe6;padding:1.25rem;box-shadow:0 18px 38px #0f172a14}.pfu-title-row{display:flex;align-items:center;justify-content:space-between;gap:1rem}.pfu-page-title{margin:0;color:#0f172a;font-size:clamp(1.5rem,3vw,2rem);font-weight:650;letter-spacing:-.035em;line-height:1.2}.pfu-actions{display:flex;align-items:center;justify-content:flex-end;gap:.5rem}.pfu-breadcrumb{margin-top:.8rem}ol{display:flex;flex-wrap:wrap;align-items:center;gap:.45rem;margin:0;padding:0;list-style:none}li,a,.pfu-current{display:inline-flex;align-items:center;gap:.45rem}a{color:#64748b;text-decoration:none;transition:color .15s ease}a:hover{color:#334155}.pfu-current{color:#334155;font-weight:600}.pfu-separator{color:#94a3b8;font-size:.65rem}li{font-size:.82rem}@media(max-width:640px){.pfu-title-row{align-items:flex-start;flex-direction:column}.pfu-actions{width:100%;justify-content:flex-start}}\n"] }]
        }] });

class LoadingDirective {
    isLoading = false;
    documentRef = inject(DOCUMENT);
    elementRef = inject(ElementRef);
    renderer = inject(Renderer2);
    overlayElement;
    spinnerElement;
    previousPosition;
    positionManagedByDirective = false;
    ngOnChanges(changes) {
        if (!changes['isLoading']) {
            return;
        }
        if (this.isLoading) {
            this.attachOverlay();
            return;
        }
        this.detachOverlay();
    }
    ngOnDestroy() {
        this.detachOverlay();
    }
    attachOverlay() {
        if (this.overlayElement) {
            return;
        }
        const hostElement = this.elementRef.nativeElement;
        const computedPosition = this.documentRef.defaultView?.getComputedStyle(hostElement).position;
        if (!computedPosition || computedPosition === 'static') {
            this.previousPosition = hostElement.style.position || null;
            this.renderer.setStyle(hostElement, 'position', 'relative');
            this.positionManagedByDirective = true;
        }
        this.renderer.setAttribute(hostElement, 'aria-busy', 'true');
        const overlayElement = this.renderer.createElement('div');
        const spinnerElement = this.renderer.createElement('span');
        this.renderer.addClass(overlayElement, 'pfu-loading-overlay');
        this.renderer.addClass(spinnerElement, 'pfu-loading-spinner');
        this.renderer.setAttribute(overlayElement, 'aria-hidden', 'true');
        this.renderer.appendChild(overlayElement, spinnerElement);
        this.renderer.appendChild(hostElement, overlayElement);
        this.ensureOverlayStyles();
        this.overlayElement = overlayElement;
        this.spinnerElement = spinnerElement;
    }
    detachOverlay() {
        const hostElement = this.elementRef.nativeElement;
        if (this.overlayElement) {
            this.renderer.removeChild(hostElement, this.overlayElement);
            this.overlayElement = undefined;
            this.spinnerElement = undefined;
        }
        this.renderer.removeAttribute(hostElement, 'aria-busy');
        if (this.positionManagedByDirective) {
            if (this.previousPosition) {
                this.renderer.setStyle(hostElement, 'position', this.previousPosition);
            }
            else {
                this.renderer.removeStyle(hostElement, 'position');
            }
            this.positionManagedByDirective = false;
            this.previousPosition = undefined;
        }
    }
    ensureOverlayStyles() {
        if (!this.overlayElement || !this.spinnerElement) {
            return;
        }
        this.renderer.setStyle(this.overlayElement, 'position', 'absolute');
        this.renderer.setStyle(this.overlayElement, 'inset', '0');
        this.renderer.setStyle(this.overlayElement, 'display', 'flex');
        this.renderer.setStyle(this.overlayElement, 'align-items', 'center');
        this.renderer.setStyle(this.overlayElement, 'justify-content', 'center');
        this.renderer.setStyle(this.overlayElement, 'background', 'rgba(255, 255, 255, 0.75)');
        this.renderer.setStyle(this.overlayElement, 'backdrop-filter', 'blur(1px)');
        this.renderer.setStyle(this.overlayElement, 'z-index', '20');
        this.renderer.setStyle(this.overlayElement, 'pointer-events', 'all');
        this.renderer.setStyle(this.spinnerElement, 'width', '2.5rem');
        this.renderer.setStyle(this.spinnerElement, 'height', '2.5rem');
        this.renderer.setStyle(this.spinnerElement, 'border-radius', '9999px');
        this.renderer.setStyle(this.spinnerElement, 'border', '0.3rem solid rgba(15, 23, 42, 0.15)');
        this.renderer.setStyle(this.spinnerElement, 'border-top-color', '#0f172a');
        this.renderer.setStyle(this.spinnerElement, 'animation', 'pfu-loading-spin 0.8s linear infinite');
        if (!this.documentRef.getElementById('pfu-loading-directive-styles')) {
            const styleElement = this.renderer.createElement('style');
            this.renderer.setAttribute(styleElement, 'id', 'pfu-loading-directive-styles');
            this.renderer.appendChild(styleElement, this.renderer.createText(`
          @keyframes pfu-loading-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `));
            if (this.documentRef.head) {
                this.renderer.appendChild(this.documentRef.head, styleElement);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: LoadingDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.7", type: LoadingDirective, isStandalone: true, selector: "[pfuLoading]", inputs: { isLoading: ["pfuLoading", "isLoading"] }, usesOnChanges: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.7", ngImport: i0, type: LoadingDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pfuLoading]',
                    standalone: true
                }]
        }], propDecorators: { isLoading: [{
                type: Input,
                args: [{ alias: 'pfuLoading' }]
            }] } });

function utcDateNotBeforeTodayValidator() {
    return (control) => {
        const valueStamp = toUtcDayStamp(control.value);
        if (valueStamp === null) {
            return null;
        }
        const todayStamp = utcTodayStamp();
        return valueStamp < todayStamp
            ? { utcDateNotBeforeToday: { minDate: new Date(todayStamp).toISOString(), actual: control.value } }
            : null;
    };
}
function utcDateNotAfterTodayValidator() {
    return (control) => {
        const valueStamp = toUtcDayStamp(control.value);
        if (valueStamp === null) {
            return null;
        }
        const todayStamp = utcTodayStamp();
        return valueStamp > todayStamp
            ? { utcDateNotAfterToday: { maxDate: new Date(todayStamp).toISOString(), actual: control.value } }
            : null;
    };
}
function utcDateMinValidator(minDate) {
    const minStamp = toUtcDayStamp(minDate);
    return (control) => {
        const valueStamp = toUtcDayStamp(control.value);
        if (valueStamp === null || minStamp === null) {
            return null;
        }
        return valueStamp < minStamp
            ? { utcDateMin: { minDate: new Date(minStamp).toISOString(), actual: control.value } }
            : null;
    };
}
function utcDateMaxValidator(maxDate) {
    const maxStamp = toUtcDayStamp(maxDate);
    return (control) => {
        const valueStamp = toUtcDayStamp(control.value);
        if (valueStamp === null || maxStamp === null) {
            return null;
        }
        return valueStamp > maxStamp
            ? { utcDateMax: { maxDate: new Date(maxStamp).toISOString(), actual: control.value } }
            : null;
    };
}

/**
 * Generated bundle index. Do not edit.
 */

export { BreadcrumbComponent, DynamicFieldComponent, DynamicFormBuilderService, DynamicFormComponent, EmptyStateComponent, LoadingDirective, defaultDynamicErrorTranslations, mapValidators, parseUtcDateValue, resolveErrorMessage, toUtcDayStamp, toUtcStartOfDayIso, utcDateMaxValidator, utcDateMinValidator, utcDateNotAfterTodayValidator, utcDateNotBeforeTodayValidator, utcTodayStamp };
//# sourceMappingURL=primeng-forms-utils.mjs.map
